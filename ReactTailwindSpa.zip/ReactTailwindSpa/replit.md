# replit.md

## Overview

This is a modern full-stack web application built with React (client) and Express.js (server) using TypeScript. The application appears to be a dashboard system with user management, activity tracking, and statistics visualization. It uses a monorepo structure with shared schema definitions and implements a clean separation between client and server code.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### Enhanced Dashboard UI - January 11, 2025
- Added comprehensive dark/light theme support with ThemeProvider
- Implemented ModeToggle component with smooth animations
- Updated all components to use semantic color tokens (foreground, background, muted-foreground, etc.)
- Enhanced header with theme toggle and improved navigation
- Added Quick Actions sidebar with common dashboard actions
- Improved chart styling with proper theming and better tooltips
- Fixed activity feed API query parameter handling
- Enhanced user table with better hover states and semantic colors
- Added proper loading states and error handling throughout
- Improved responsive design for mobile and desktop layouts

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Schema Management**: Shared schema definitions using Drizzle and Zod
- **Development**: Hot reload with Vite integration in development mode

### Project Structure
```
├── client/          # React frontend application
├── server/          # Express.js backend application
├── shared/          # Shared TypeScript definitions and schemas
├── migrations/      # Database migration files
└── dist/           # Build output directory
```

## Key Components

### Data Models
- **Users**: User management with roles, status, and profile information
- **Activities**: Activity tracking system for user actions
- **Stats**: Dashboard statistics and metrics

### Frontend Components
- **Dashboard**: Main dashboard with statistics cards, charts, and activity feed
- **User Management**: Complete CRUD operations for users with table view
- **Activity Feed**: Real-time activity monitoring
- **Analytics Chart**: Data visualization using Recharts

### Backend Services
- **Storage Layer**: Abstracted storage interface with in-memory implementation
- **REST API**: RESTful endpoints for users, activities, and statistics
- **Validation**: Zod schema validation for all API inputs

## Data Flow

1. **Client Requests**: React components use TanStack Query hooks to fetch data
2. **API Layer**: Express.js routes handle HTTP requests with validation
3. **Storage Layer**: Abstracted storage interface manages data operations
4. **Database**: PostgreSQL with Drizzle ORM for data persistence
5. **Real-time Updates**: Optimistic updates and cache invalidation

## External Dependencies

### UI and Styling
- **Radix UI**: Accessible, unstyled UI components
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Recharts**: Charting library for data visualization

### Backend Services
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle Kit**: Database toolkit and migration system

### Development Tools
- **Vite**: Build tool with HMR and optimized bundling
- **TypeScript**: Type safety across the entire stack
- **ESBuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds the React application to `dist/public`
2. **Backend Build**: ESBuild bundles the Express server to `dist/index.js`
3. **Database Migration**: Drizzle Kit handles schema migrations

### Environment Configuration
- **Development**: Uses Vite dev server with Express API proxy
- **Production**: Serves static files from Express with API routes
- **Database**: Requires `DATABASE_URL` environment variable

### Scripts
- `npm run dev`: Development mode with hot reload
- `npm run build`: Production build for both client and server
- `npm run start`: Production server
- `npm run db:push`: Push database schema changes

The application follows modern web development best practices with strong type safety, component reusability, and clean architecture patterns. The storage layer abstraction allows for easy switching between different database implementations or adding features like caching.