import { useQuery } from "@tanstack/react-query";
import type { Activity } from "@shared/schema";

export function useActivities(limit?: number) {
  return useQuery<Activity[]>({
    queryKey: ["/api/activities", ...(limit ? [limit] : [])],
    queryFn: async () => {
      const url = limit ? `/api/activities?limit=${limit}` : "/api/activities";
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch activities");
      }
      return response.json();
    },
  });
}
