import { useQuery } from "@tanstack/react-query";
import type { Stats } from "@shared/schema";

export function useStats() {
  return useQuery<Stats>({
    queryKey: ["/api/stats"],
  });
}

export function useChartData() {
  return useQuery<Array<{
    day: number;
    users: number;
    revenue: number;
    conversion: number;
  }>>({
    queryKey: ["/api/chart-data"],
  });
}
