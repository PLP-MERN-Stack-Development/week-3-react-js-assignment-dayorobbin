import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Bell, Menu, ChevronDown, Layers } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { ModeToggle } from "@/components/mode-toggle";

export function Header() {
  const isMobile = useIsMobile();
  
  return (
    <header className="bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Brand */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center">
                <Layers className="text-primary-foreground h-4 w-4" />
              </div>
              <span className="ml-2 text-xl font-bold text-foreground">ReactDash</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          {!isMobile && (
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-primary border-b-2 border-primary px-1 pb-4 text-sm font-medium">
                Dashboard
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground px-1 pb-4 text-sm font-medium hover:border-b-2 hover:border-border transition-colors">
                Analytics
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground px-1 pb-4 text-sm font-medium hover:border-b-2 hover:border-border transition-colors">
                Users
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground px-1 pb-4 text-sm font-medium hover:border-b-2 hover:border-border transition-colors">
                Settings
              </a>
            </nav>
          )}

          {/* User Profile */}
          <div className="flex items-center space-x-2">
            <ModeToggle />
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&h=100" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  {!isMobile && <span className="text-foreground font-medium">John Doe</span>}
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile menu button */}
            {isMobile && (
              <Button variant="ghost" size="icon" className="ml-4">
                <Menu className="h-5 w-5" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
