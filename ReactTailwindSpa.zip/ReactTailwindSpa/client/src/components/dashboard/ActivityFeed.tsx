import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useActivities } from "@/hooks/useActivities";
import { Skeleton } from "@/components/ui/skeleton";
import { UserPlus, ShoppingCart, AlertTriangle, Settings } from "lucide-react";

const activityIcons = {
  user_register: UserPlus,
  order_complete: ShoppingCart,
  system_alert: AlertTriangle,
  settings_update: Settings,
  user_update: Settings,
  user_delete: AlertTriangle,
};

const activityColors = {
  user_register: "bg-blue-100 text-blue-600",
  order_complete: "bg-green-100 text-green-600",
  system_alert: "bg-amber-100 text-amber-600",
  settings_update: "bg-purple-100 text-purple-600",
  user_update: "bg-purple-100 text-purple-600",
  user_delete: "bg-red-100 text-red-600",
};

function getTimeAgo(date: Date) {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes} minutes ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hours ago`;
  
  const days = Math.floor(hours / 24);
  return `${days} days ago`;
}

export function ActivityFeed() {
  const { data: activities, isLoading } = useActivities(4);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="flex items-start space-x-3">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div className="flex-1 space-y-1">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-20" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!activities || activities.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500">
            No recent activities
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => {
          const Icon = activityIcons[activity.type as keyof typeof activityIcons] || Settings;
          const colorClass = activityColors[activity.type as keyof typeof activityColors] || "bg-gray-100 text-gray-600";
          
          return (
            <div key={activity.id} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-8 h-8 ${colorClass} rounded-full flex items-center justify-center`}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                <p className="text-xs text-gray-500">
                  {getTimeAgo(new Date(activity.createdAt!))}
                </p>
              </div>
            </div>
          );
        })}
        
        <Button variant="ghost" className="w-full mt-4 text-blue-600 hover:text-blue-700">
          View all activities
        </Button>
      </CardContent>
    </Card>
  );
}
