import { users, activities, stats, type User, type InsertUser, type Activity, type InsertActivity, type Stats, type InsertStats } from "@shared/schema";

export interface IStorage {
  // User operations
  getUsers(): Promise<User[]>;
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // Activity operations
  getActivities(): Promise<Activity[]>;
  getRecentActivities(limit: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Stats operations
  getStats(): Promise<Stats | undefined>;
  updateStats(stats: InsertStats): Promise<Stats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private activities: Map<number, Activity>;
  private stats: Stats;
  private currentUserId: number;
  private currentActivityId: number;

  constructor() {
    this.users = new Map();
    this.activities = new Map();
    this.currentUserId = 1;
    this.currentActivityId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Initialize stats
    this.stats = {
      id: 1,
      totalUsers: 24567,
      revenue: 89432,
      growthRate: "23.1%",
      conversionRate: "4.6%",
      updatedAt: new Date(),
    };

    // Initialize users
    const sampleUsers = [
      { name: "Sarah Johnson", email: "sarah.johnson@example.com", username: "sjohnson", role: "admin", status: "active", avatar: "https://pixabay.com/get/g0c25f58a2b3a6530830d389abbce97340c4305b9f30a4404bbbfeec775c8224efb71ac7e2be426ce83f231f58d1fe9d8a47777d726968f0a55a811331457a244_1280.jpg" },
      { name: "Michael Chen", email: "michael.chen@example.com", username: "mchen", role: "user", status: "active", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&h=100" },
      { name: "Emma Davis", email: "emma.davis@example.com", username: "edavis", role: "moderator", status: "pending", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&h=100" },
    ];

    sampleUsers.forEach(user => {
      const id = this.currentUserId++;
      this.users.set(id, { ...user, id, createdAt: new Date() });
    });

    // Initialize activities
    const sampleActivities = [
      { type: "user_register", description: "New user registered", userId: 1 },
      { type: "order_complete", description: "Order completed", userId: 2 },
      { type: "system_alert", description: "System alert", userId: null },
      { type: "settings_update", description: "Settings updated", userId: 3 },
    ];

    sampleActivities.forEach(activity => {
      const id = this.currentActivityId++;
      this.activities.set(id, { ...activity, id, createdAt: new Date() });
    });
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values()).sort((a, b) => a.id - b.id);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    
    // Update stats
    this.stats.totalUsers = this.users.size;
    
    // Add activity
    await this.createActivity({
      type: "user_register",
      description: `${user.name} registered`,
      userId: id,
    });
    
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    
    // Add activity
    await this.createActivity({
      type: "user_update",
      description: `${user.name} updated`,
      userId: id,
    });
    
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    const user = this.users.get(id);
    if (!user) return false;

    this.users.delete(id);
    this.stats.totalUsers = this.users.size;
    
    // Add activity
    await this.createActivity({
      type: "user_delete",
      description: `${user.name} deleted`,
      userId: null,
    });
    
    return true;
  }

  async getActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getRecentActivities(limit: number): Promise<Activity[]> {
    const activities = await this.getActivities();
    return activities.slice(0, limit);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = { ...insertActivity, id, createdAt: new Date() };
    this.activities.set(id, activity);
    return activity;
  }

  async getStats(): Promise<Stats | undefined> {
    return this.stats;
  }

  async updateStats(newStats: InsertStats): Promise<Stats> {
    this.stats = { ...this.stats, ...newStats, updatedAt: new Date() };
    return this.stats;
  }
}

export const storage = new MemStorage();
